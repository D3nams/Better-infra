import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ContactForm from './components/ContactForm';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Hero />
      <div className="py-16 px-4 sm:px-6 lg:px-8" id="contact">
        <ContactForm />
      </div>
    </div>
  );
}

export default App;