import React from 'react';
import { ArrowRight } from 'lucide-react';
import ServiceCards from './ServiceCards';

const Hero = () => {
  return (
    <>
      <div className="relative min-h-screen">
        {/* Background Image */}
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <div className="absolute inset-0 bg-black opacity-50"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 flex items-center justify-center min-h-screen">
          <div className="text-center text-white px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 animate-fade-in">
              Building Tomorrow's Infrastructure Today
            </h1>
            <p className="text-xl sm:text-2xl mb-8 max-w-3xl mx-auto animate-fade-in-delay">
              Together we win at Vertex Infra, where excellence meets innovation in construction
              and infrastructure development.
            </p>
            <div className="space-x-4 animate-fade-in-delay-2">
              <a
                href="#contact"
                className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-red-600 hover:bg-red-700 transition transform hover:scale-105"
              >
                Get Started <ArrowRight className="ml-2 h-5 w-5" />
              </a>
              <a
                href="#services"
                className="inline-flex items-center px-8 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-gray-900 transition transform hover:scale-105"
              >
                Our Services
              </a>
            </div>
          </div>
        </div>
      </div>
      <ServiceCards />
    </>
  );
};

export default Hero;