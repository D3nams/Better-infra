import React, { useState } from 'react';
import { Send, RefreshCw } from 'lucide-react';

interface ConsultantFormData {
  name: string;
  email: string;
  phone: string;
  expertise: string;
  experience: string;
  availability: string;
  resume: File | null;
  portfolio: string;
  message: string;
}

const ConsultantForm = () => {
  const [formData, setFormData] = useState<ConsultantFormData>({
    name: '',
    email: '',
    phone: '',
    expertise: '',
    experience: '',
    availability: '',
    resume: null,
    portfolio: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log(formData);
    // Handle form submission
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      expertise: '',
      experience: '',
      availability: '',
      resume: null,
      portfolio: '',
      message: ''
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Full Name</label>
          <input
            type="text"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input
            type="email"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Phone Number</label>
          <input
            type="tel"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.phone}
            onChange={(e) => setFormData({...formData, phone: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Area of Expertise</label>
          <select
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.expertise}
            onChange={(e) => setFormData({...formData, expertise: e.target.value})}
          >
            <option value="">Select expertise</option>
            <option value="construction">Construction Management</option>
            <option value="architecture">Architecture</option>
            <option value="civil">Civil Engineering</option>
            <option value="mechanical">Mechanical Engineering</option>
            <option value="electrical">Electrical Engineering</option>
            <option value="project">Project Management</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Years of Experience</label>
          <select
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.experience}
            onChange={(e) => setFormData({...formData, experience: e.target.value})}
          >
            <option value="">Select experience</option>
            <option value="1-3">1-3 years</option>
            <option value="4-6">4-6 years</option>
            <option value="7-10">7-10 years</option>
            <option value="10+">10+ years</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Availability</label>
          <select
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.availability}
            onChange={(e) => setFormData({...formData, availability: e.target.value})}
          >
            <option value="">Select availability</option>
            <option value="full-time">Full-time</option>
            <option value="part-time">Part-time</option>
            <option value="contract">Contract</option>
            <option value="project-based">Project-based</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Resume/CV</label>
        <input
          type="file"
          accept=".pdf,.doc,.docx"
          className="mt-1 block w-full text-sm text-gray-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-md file:border-0
            file:text-sm file:font-semibold
            file:bg-red-50 file:text-red-700
            hover:file:bg-red-100"
          onChange={(e) => setFormData({...formData, resume: e.target.files?.[0] || null})}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Portfolio URL (Optional)</label>
        <input
          type="url"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
          value={formData.portfolio}
          onChange={(e) => setFormData({...formData, portfolio: e.target.value})}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Additional Information</label>
        <textarea
          rows={4}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
          value={formData.message}
          onChange={(e) => setFormData({...formData, message: e.target.value})}
        ></textarea>
      </div>

      <div className="flex space-x-4">
        <button
          type="submit"
          className="flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition transform hover:scale-105"
        >
          Submit Application <Send className="ml-2 h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition transform hover:scale-105"
        >
          Reset Form <RefreshCw className="ml-2 h-4 w-4" />
        </button>
      </div>
    </form>
  );
};

export default ConsultantForm;