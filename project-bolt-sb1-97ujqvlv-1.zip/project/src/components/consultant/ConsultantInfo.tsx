import React from 'react';
import { Briefcase, Clock, Award, Globe2 } from 'lucide-react';

const benefits = [
  {
    icon: Briefcase,
    title: 'Flexible Work',
    description: 'Choose from various engagement models including full-time, part-time, and project-based opportunities',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80'
  },
  {
    icon: Clock,
    title: 'Competitive Rates',
    description: 'Earn competitive compensation based on your expertise and experience level',
    image: 'https://images.unsplash.com/photo-1604933762023-7213af7ff7a7?auto=format&fit=crop&q=80'
  },
  {
    icon: Award,
    title: 'Professional Growth',
    description: 'Work on challenging projects and expand your professional portfolio',
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80'
  },
  {
    icon: Globe2,
    title: 'Global Projects',
    description: 'Opportunity to work on international projects across Nigeria and UAE',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80'
  }
];

const ConsultantInfo = () => {
  return (
    <div className="bg-gray-50 p-8 rounded-lg">
      <h3 className="text-2xl font-bold text-gray-900 mb-6 animate-fade-in">Why Join Vertex Infra?</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {benefits.map((benefit, index) => (
          <div 
            key={benefit.title}
            className="relative group overflow-hidden rounded-lg shadow-sm transition-transform hover:scale-105"
            style={{
              animation: `fadeIn 0.5s ease-out ${index * 0.2}s forwards`,
              opacity: 0
            }}
          >
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${benefit.image})` }}
            >
              <div className="absolute inset-0 bg-black opacity-60 group-hover:opacity-70 transition-opacity duration-300"></div>
            </div>
            <div className="relative p-6 text-white">
              <benefit.icon className="w-8 h-8 text-red-400 mb-4" />
              <h4 className="text-lg font-semibold mb-2">{benefit.title}</h4>
              <p className="text-gray-200">{benefit.description}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 p-6 bg-red-50 rounded-lg border border-red-100 animate-fade-in-delay">
        <h4 className="text-lg font-semibold text-red-900 mb-4">Requirements</h4>
        <ul className="space-y-2 text-red-800">
          <li className="animate-slide-in" style={{ animationDelay: '0.1s' }}>• Relevant degree in Engineering, Architecture, or related field</li>
          <li className="animate-slide-in" style={{ animationDelay: '0.2s' }}>• Professional certification in your area of expertise</li>
          <li className="animate-slide-in" style={{ animationDelay: '0.3s' }}>• Minimum of 1 year experience in construction industry</li>
          <li className="animate-slide-in" style={{ animationDelay: '0.4s' }}>• Strong communication and problem-solving skills</li>
          <li className="animate-slide-in" style={{ animationDelay: '0.5s' }}>• Ability to work in a team environment</li>
        </ul>
      </div>
    </div>
  );
};

export default ConsultantInfo;