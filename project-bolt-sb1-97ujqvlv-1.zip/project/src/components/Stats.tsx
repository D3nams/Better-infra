import React from 'react';
import { Building2, Users2, Globe2, Trophy } from 'lucide-react';

const stats = [
  {
    icon: Building2,
    value: '500+',
    label: 'Projects Completed',
    description: 'Successful construction projects across multiple sectors'
  },
  {
    icon: Users2,
    value: '200+',
    label: 'Expert Consultants',
    description: 'Skilled professionals in our global network'
  },
  {
    icon: Globe2,
    value: '2',
    label: 'Countries',
    description: 'Strategic presence in Nigeria and UAE'
  },
  {
    icon: Trophy,
    value: '15+',
    label: 'Years Experience',
    description: 'Industry expertise and excellence'
  }
];

const Stats = () => {
  return (
    <div className="bg-white py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="relative group p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              style={{
                animation: `fadeIn 0.5s ease-out ${index * 0.2}s forwards`,
                opacity: 0
              }}
            >
              <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-red-400 rounded-xl opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
              <stat.icon className="h-12 w-12 text-red-600 mb-4" />
              <div className="relative">
                <h3 className="text-4xl font-bold text-gray-900 mb-2">{stat.value}</h3>
                <p className="text-lg font-semibold text-gray-800 mb-2">{stat.label}</p>
                <p className="text-gray-600">{stat.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Stats;