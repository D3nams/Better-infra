import React, { useState } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full bg-white shadow-lg z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <img 
                src="/vertex-logo.png" 
                alt="Vertex Infra" 
                className="h-12 w-auto"
              />
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="/" className="text-gray-700 hover:text-red-600 transition">Home</a>
            <div className="relative group">
              <button className="flex items-center text-gray-700 hover:text-red-600 transition">
                Services <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              <div className="absolute hidden group-hover:block w-48 bg-white shadow-lg rounded-md mt-2">
                <a href="/services/construction" className="block px-4 py-2 hover:bg-gray-100">Construction</a>
                <a href="/services/infrastructure" className="block px-4 py-2 hover:bg-gray-100">Infrastructure</a>
                <a href="/services/real-estate" className="block px-4 py-2 hover:bg-gray-100">Real Estate</a>
              </div>
            </div>
            <a href="/projects" className="text-gray-700 hover:text-red-600 transition">Projects</a>
            <a href="/about" className="text-gray-700 hover:text-red-600 transition">About</a>
            <a href="/contact" className="text-gray-700 hover:text-red-600 transition">Contact</a>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-700">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="/" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Home</a>
            <a href="/services" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Services</a>
            <a href="/projects" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Projects</a>
            <a href="/about" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">About</a>
            <a href="/contact" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Contact</a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;