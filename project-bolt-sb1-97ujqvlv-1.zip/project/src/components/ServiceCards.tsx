import React from 'react';
import { Building2, Building, Warehouse, Hotel, BadgeDollarSign, Truck } from 'lucide-react';

const services = [
  {
    title: 'Construction',
    description: 'Expert construction services for commercial and residential projects',
    icon: Building2,
    image: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&q=80'
  },
  {
    title: 'Infrastructure Development',
    description: 'Building sustainable infrastructure for growing communities',
    icon: Building,
    image: 'https://images.unsplash.com/photo-1590846406792-0adc7f938f1d?auto=format&fit=crop&q=80'
  },
  {
    title: 'Real Estate Construction',
    description: 'Premium real estate development and construction services',
    icon: Warehouse,
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80'
  },
  {
    title: 'Hotel Construction',
    description: 'Specialized construction services for the hospitality industry',
    icon: Hotel,
    image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80'
  },
  {
    title: 'Real Estate Investment',
    description: 'Strategic real estate investment opportunities',
    icon: BadgeDollarSign,
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80'
  },
  {
    title: 'Heavy Machinery Investment',
    description: 'Investment in construction and industrial equipment',
    icon: Truck,
    image: 'https://images.unsplash.com/photo-1573611030146-ff6916c398fa?auto=format&fit=crop&q=80'
  }
];

const ServiceCards = () => {
  return (
    <div id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-16 text-gray-900 animate-fade-in">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={service.title}
              className="group relative overflow-hidden rounded-xl shadow-lg transform transition-all duration-500 hover:scale-105"
              style={{ 
                height: '400px',
                animation: `scaleIn 0.5s ease-out ${index * 0.1}s forwards`,
                opacity: 0
              }}
            >
              <div 
                className="absolute inset-0 bg-cover bg-center transition-all duration-700 group-hover:scale-110"
                style={{ backgroundImage: `url(${service.image})` }}
              >
                <div className="absolute inset-0 bg-black opacity-40 group-hover:opacity-60 transition-opacity duration-500"></div>
              </div>
              <div className="relative h-full flex flex-col justify-end p-8 text-white">
                <service.icon className="w-12 h-12 mb-4 transform transition-transform duration-500 group-hover:scale-110" />
                <h3 className="text-2xl font-bold mb-2">{service.title}</h3>
                <p className="opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  {service.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServiceCards;