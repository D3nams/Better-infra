import React, { useState } from 'react';
import { Send, RefreshCw } from 'lucide-react';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: '',
    terms: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log(formData);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      service: '',
      message: '',
      terms: false
    });
  };

  return (
    <div className="bg-white p-8 rounded-lg shadow-xl max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Contact Us</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Name</label>
          <input
            type="text"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input
            type="email"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Phone Number</label>
          <input
            type="tel"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.phone}
            onChange={(e) => setFormData({...formData, phone: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Service Inquiry</label>
          <select
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.service}
            onChange={(e) => setFormData({...formData, service: e.target.value})}
          >
            <option value="">Select a service</option>
            <option value="construction">Construction</option>
            <option value="infrastructure">Infrastructure Development</option>
            <option value="real-estate">Real Estate Construction</option>
            <option value="hotel">Hotel Construction</option>
            <option value="real-estate-investment">Real Estate Investment</option>
            <option value="machinery">Heavy Machinery Investment</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Message</label>
          <textarea
            rows={4}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            value={formData.message}
            onChange={(e) => setFormData({...formData, message: e.target.value})}
          ></textarea>
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
            checked={formData.terms}
            onChange={(e) => setFormData({...formData, terms: e.target.checked})}
          />
          <label className="ml-2 block text-sm text-gray-700">
            I agree to the Terms and Conditions
          </label>
        </div>

        <div className="flex space-x-4">
          <button
            type="submit"
            className="flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
          >
            Submit <Send className="ml-2 h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
          >
            Reset <RefreshCw className="ml-2 h-4 w-4" />
          </button>
        </div>
      </form>

      <div className="mt-8 border-t pt-8">
        <h3 className="text-xl font-semibold mb-4">Our Offices</h3>
        <div className="space-y-4">
          <div>
            <p className="font-medium">Nigeria Office</p>
            <p>Hong, Nigeria</p>
          </div>
          <div>
            <p className="font-medium">UAE Office</p>
            <p>Dubai, UAE</p>
          </div>
        </div>

        <div className="mt-6">
          <p className="font-medium">Email:</p>
          <a href="mailto:info@vertexinfra.com" className="text-red-600 hover:text-red-700">
            info@vertexinfra.com
          </a>
        </div>

        <div className="mt-6">
          <p className="font-medium mb-3">Follow Us:</p>
          <div className="flex space-x-4">
            <a href="https://instagram.com/VertexInfraOfficial" className="text-gray-600 hover:text-red-600">Instagram</a>
            <a href="https://twitter.com/VertexInfraOfficial" className="text-gray-600 hover:text-red-600">Twitter</a>
            <a href="https://facebook.com/VertexInfraOfficial" className="text-gray-600 hover:text-red-600">Facebook</a>
            <a href="https://linkedin.com/company/VertexInfraOfficial" className="text-gray-600 hover:text-red-600">LinkedIn</a>
          </div>
        </div>

        <div className="mt-6 text-sm text-gray-500">
          <a href="/privacy" className="hover:text-red-600">Privacy Policy</a> |{' '}
          <a href="/terms" className="hover:text-red-600">Terms of Service</a> |{' '}
          <a href="/disclaimer" className="hover:text-red-600">Disclaimer</a>
        </div>
      </div>
    </div>
  );
};

export default ContactForm;